import React, { useRef, useState } from "react";
import PhoneScreen from "./components/PhoneScreen";

const API_BASE =
  import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

function App() {
  const [isCalling, setIsCalling] = useState(false);
  const [callStatus, setCallStatus] = useState("Call disconnected");
  const [history, setHistory] = useState([]);
  const [isRecording, setIsRecording] = useState(false);

  const recorderRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);

  const startCall = async () => {
    try {
      setIsCalling(true);
      setCallStatus("Connecting...");

      const res = await fetch(`${API_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ start: true, history: [], userText: "" })
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const agentText = data.agentText || "(no reply)";

      const firstMsg = { role: "assistant", content: agentText };
      setHistory([firstMsg]);

      await speak(agentText);

      setCallStatus("In call");
    } catch (err) {
      console.error("Start call error:", err);
      setCallStatus("Error starting call: " + err.message);
      setIsCalling(false);
      setHistory([]);
    }
  };

  const endCall = () => {
    // stop any ongoing recording
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
    }
    setIsRecording(false);

    setIsCalling(false);
    setCallStatus("Call disconnected");
    setHistory([]);
  };

  /** TOGGLE MIC: tap to start, tap again to stop */
  const onMicPress = async () => {
    if (!isCalling) return;

    // STOP recording (second tap)
    if (isRecording) {
      if (recorderRef.current && recorderRef.current.state !== "inactive") {
        recorderRef.current.stop(); // onstop will handle processing
      }
      setIsRecording(false);
      return;
    }

    // START recording (first tap)
    try {
      setCallStatus("Listening...");

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });

      streamRef.current = stream;
      recorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = async () => {
        // stop mic stream
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((t) => t.stop());
          streamRef.current = null;
        }

        const chunks = chunksRef.current;
        chunksRef.current = [];

        if (!chunks || chunks.length === 0) {
          setCallStatus("No audio captured, try again");
          return;
        }

        setCallStatus("Processing...");

        try {
          const blob = new Blob(chunks, { type: "audio/webm" });
          const file = new File([blob], "input.webm");

          const form = new FormData();
          form.append("audio", file);

          // 1) ASR
          const asrRes = await fetch(`${API_BASE}/api/asr`, {
            method: "POST",
            body: form
          });

          const asrData = await asrRes.json();
          if (!asrRes.ok) {
            throw new Error(asrData.error || `ASR HTTP ${asrRes.status}`);
          }

          const userText = (asrData.text || "").trim();
          if (!userText) {
            setCallStatus("I didn't catch that, try again");
            return;
          }

          const userMsg = { role: "user", content: userText };

          // 2) Chat – send full history + this user message
          const convHistory = [...history, userMsg];
          const chatRes = await fetch(`${API_BASE}/api/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ history: convHistory, userText })
          });

          const chatData = await chatRes.json();
          if (!chatRes.ok) {
            throw new Error(chatData.error || `Chat HTTP ${chatRes.status}`);
          }

          const agentText = chatData.agentText || "(no reply)";
          const agentMsg = { role: "assistant", content: agentText };

          // update transcript
          setHistory((prev) => [...prev, userMsg, agentMsg]);

          // 3) TTS
          await speak(agentText);
          setCallStatus("In call");
        } catch (err) {
          console.error("Call turn error:", err);
          setCallStatus("Error during call: " + err.message);
        }
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Mic error:", err);
      setCallStatus("Microphone error: " + err.message);
    }
  };

const speak = async (text) => {
  try {
    const res = await fetch(`${API_BASE}/api/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });

    const data = await res.json();
    if (!res.ok || data.error) {
      throw new Error(
        typeof data.error === "string" ? data.error : JSON.stringify(data.error)
      );
    }

    const { audioBase64, mimeType } = data;
    if (!audioBase64) {
      throw new Error("No audio returned from TTS");
    }

    const audio = new Audio(`data:${mimeType};base64,${audioBase64}`);
    await audio.play();
  } catch (err) {
    console.error("TTS error:", err);
    setCallStatus("TTS error: " + err.message);
  }
};


  return (
    <PhoneScreen
      isCalling={isCalling}
      callStatus={callStatus}
      history={history}
      onStartCall={startCall}
      onEndCall={endCall}
      onMicPress={onMicPress}
      isRecording={isRecording}
    />
  );
}

export default App;
