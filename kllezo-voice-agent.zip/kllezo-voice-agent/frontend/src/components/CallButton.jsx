import React from "react";

function CallButton({ label, type, onClick }) {
  return (
    <button className={`call-button ${type}`} onClick={onClick}>
      {label}
    </button>
  );
}

export default CallButton;
