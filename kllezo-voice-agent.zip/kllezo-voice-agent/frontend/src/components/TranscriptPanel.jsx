import React from "react";

function TranscriptPanel({ history }) {
  return (
    <div className="transcript">
      {history.map((msg, i) => (
        <div
          key={i}
          className={`bubble ${msg.role === "assistant" ? "agent" : "user"}`}
        >
          {msg.content}
        </div>
      ))}
    </div>
  );
}

export default TranscriptPanel;
