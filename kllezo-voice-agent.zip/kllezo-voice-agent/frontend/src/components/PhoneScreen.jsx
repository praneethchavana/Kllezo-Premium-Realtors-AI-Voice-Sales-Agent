import React from "react";
import TranscriptPanel from "./TranscriptPanel";
import CallButton from "./CallButton";

function PhoneScreen({
  isCalling,
  callStatus,
  history,
  onStartCall,
  onEndCall,
  onMicPress,
  isRecording
}) {
  return (
    <div className="phone-container">
      <div className="header">
        <div className="title">Kllezo Premium Realtors</div>
        <div className="subtitle">Talking to: Aditya (AI Sales Executive)</div>
      </div>

      <div className="call-status">{callStatus}</div>

      <TranscriptPanel history={history} />

      {isCalling ? (
        <>
          <button
            className={`mic-button ${isRecording ? "recording" : ""}`}
            onClick={onMicPress}
          >
            {isRecording ? "⏹️" : "🎤"}
          </button>
          <CallButton label="End Call" type="end" onClick={onEndCall} />
        </>
      ) : (
        <CallButton label="Start Call" type="start" onClick={onStartCall} />
      )}
    </div>
  );
}

export default PhoneScreen;
