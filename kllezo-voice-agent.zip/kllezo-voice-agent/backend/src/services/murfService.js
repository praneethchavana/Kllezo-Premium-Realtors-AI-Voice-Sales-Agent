const axios = require('axios');

const MURF_API_KEY = process.env.MURF_API_KEY || '';
const MURF_VOICE_ID = process.env.MURF_VOICE_ID || 'en-IN-eashwar';
const MURF_MODEL_VERSION = process.env.MURF_MODEL_VERSION || 'gen2'; // 👈 use gen2

if (!MURF_API_KEY) {
  console.warn('⚠️ MURF_API_KEY not set. TTS will fail.');
}

async function synthesizeSpeech(text) {
  if (!MURF_API_KEY) throw new Error('MURF_API_KEY not configured');
  if (!MURF_VOICE_ID) throw new Error('MURF_VOICE_ID not configured');

  const url = 'https://api.murf.ai/v1/speech/generate';

  const headers = {
    'Content-Type': 'application/json',
    'api-key': MURF_API_KEY
  };

  // ✅ CORRECT SCHEMA FOR MURF
  const payload = {
    text,
    voiceId: MURF_VOICE_ID,          // camelCase per docs
    modelVersion: MURF_MODEL_VERSION, // 👈 THIS is what fixes the FALCON error
    format: 'MP3',
    sampleRate: 24000
  };

  const res = await axios.post(url, payload, { headers });

  const data = res.data;
  const audioUrl = data.audioFile || data.audio_file || data.audio_url;

  if (!audioUrl) {
    console.error('Murf response without audio URL:', data);
    throw new Error('Murf response missing audioFile');
  }

  const audioRes = await axios.get(audioUrl, { responseType: 'arraybuffer' });

  const mimeType = audioRes.headers['content-type'] || 'audio/mpeg';

  return {
    audioBuffer: Buffer.from(audioRes.data),
    mimeType
  };
}

module.exports = { synthesizeSpeech };
