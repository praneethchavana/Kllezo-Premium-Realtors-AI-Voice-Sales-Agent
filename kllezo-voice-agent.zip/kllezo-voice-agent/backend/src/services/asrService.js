const axios = require('axios');

const ASR_API_KEY = process.env.ASR_API_KEY;
const ASSEMBLY_BASE_URL = 'https://api.assemblyai.com/v2';

if (!ASR_API_KEY) {
  console.warn('⚠️ ASR_API_KEY is not set. AssemblyAI ASR will fail.');
}

async function uploadAudio(buffer) {
  const res = await axios.post(`${ASSEMBLY_BASE_URL}/upload`, buffer, {
    headers: {
      authorization: ASR_API_KEY,
      'content-type': 'application/octet-stream',
      'transfer-encoding': 'chunked'
    },
    maxContentLength: Infinity,
    maxBodyLength: Infinity
  });
  return res.data.upload_url;
}

async function pollTranscript(id) {
  while (true) {
    const res = await axios.get(`${ASSEMBLY_BASE_URL}/transcript/${id}`, {
      headers: { authorization: ASR_API_KEY }
    });
    const data = res.data;

    if (data.status === 'completed') return data.text || '';
    if (data.status === 'error') throw new Error(data.error || 'AssemblyAI error');

    await new Promise((r) => setTimeout(r, 1500));
  }
}

async function transcribeAudio(buffer) {
  if (!ASR_API_KEY) throw new Error('ASR_API_KEY not configured');

  const uploadUrl = await uploadAudio(buffer);

  const transcriptRes = await axios.post(
    `${ASSEMBLY_BASE_URL}/transcript`,
    { audio_url: uploadUrl },
    { headers: { authorization: ASR_API_KEY } }
  );

  const transcriptId = transcriptRes.data.id;
  const text = await pollTranscript(transcriptId);
  return text;
}

module.exports = { transcribeAudio };
