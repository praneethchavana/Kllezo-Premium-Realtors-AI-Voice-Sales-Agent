// backend/src/routes/chat.js
const express = require('express');
const chatService = require('../services/chatService');

const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { history = [], userText = '', start = false } = req.body;
    const agentText = await chatService.getAgentReply({ history, userText, start });
    res.json({ agentText });
  } catch (err) {
    // 🔥 Log more detailed info
    const status = err.response?.status;
    const data = err.response?.data;
    console.error('Chat error status:', status);
    console.error('Chat error data:', data);
    console.error('Chat error message:', err.message);

    // 🔥 Send the message/data back to frontend so you can see it
    if (data) {
      return res.status(500).json({ error: JSON.stringify(data) });
    }
    return res.status(500).json({ error: err.message || 'Unknown chat error' });
  }
});

module.exports = router;
