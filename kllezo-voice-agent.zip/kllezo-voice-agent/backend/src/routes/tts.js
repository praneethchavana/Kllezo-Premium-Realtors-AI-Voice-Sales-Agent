const express = require('express');
const murfService = require('../services/murfService');

const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Missing text' });
    }

    const { audioBuffer, mimeType } = await murfService.synthesizeSpeech(text);
    const base64 = audioBuffer.toString('base64');

    console.log('✅ Murf TTS generated, bytes:', audioBuffer.length);

    res.json({ audioBase64: base64, mimeType });
  } catch (err) {
    const status = err.response?.status;
    const data = err.response?.data;

    console.error('❌ TTS error status:', status);
    console.error('❌ TTS error data:', data);
    console.error('❌ TTS error message:', err.message);

    return res
      .status(500)
      .json({ error: data || err.message || 'Failed to generate TTS audio' });
  }
});

module.exports = router;
