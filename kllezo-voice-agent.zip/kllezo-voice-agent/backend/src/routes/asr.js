const express = require('express');
const multer = require('multer');
const asrService = require('../services/asrService');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.post('/', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file || !req.file.buffer) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    const text = await asrService.transcribeAudio(req.file.buffer);
    res.json({ text });
  } catch (err) {
    console.error('ASR error:', err);
    res.status(500).json({ error: 'Failed to transcribe audio' });
  }
});

module.exports = router;
